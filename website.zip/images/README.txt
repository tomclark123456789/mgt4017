Put these 4 images in this folder (download them from Shopify admin > Content > Files):

rs-5d014ea0.jpg
rs-36bd8e53.jpg
rs-ebec3836.jpg
rs-f959a02e.jpg

The names must match exactly.
